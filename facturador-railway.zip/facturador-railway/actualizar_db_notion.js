/**
 * actualizar_db_notion.js — Agrega columnas faltantes a la DB existente
 * ======================================================================
 * Ejecutar UNA SOLA VEZ desde tu PC para preparar la DB de Notion
 * con todas las columnas que necesita el daemon.
 *
 * Uso:
 *   node actualizar_db_notion.js
 */
"use strict";

require("dotenv").config();
const { Client } = require("@notionhq/client");

const notion     = new Client({ auth: process.env.NOTION_TOKEN });
const DB_ID      = process.env.NOTION_DB_ID;

async function main() {
    console.log("🔧 Actualizando schema de la DB en Notion...");

    await notion.databases.update({
        database_id: DB_ID,
        properties: {
            // Columnas que ya existen (no se tocan) — las dejamos para referencia
            // "Razón Social", "CUIT Cliente", "Fecha Emisión", "Importe",
            // "Nro Comprobante", "CAE", "CAE Vencimiento", "Estado", "Tipo",
            // "Período Desde", "Período Hasta", "Punto de Venta", "Nro Factura Original"

            // ── Columnas nuevas que necesita el daemon ─────────────────
            "Domicilio": {
                rich_text: {}
            },
            "Condición IVA": {
                select: {
                    options: [
                        { name: "Consumidor Final",       color: "gray"   },
                        { name: "Responsable Inscripto",  color: "blue"   },
                        { name: "Exento",                 color: "green"  },
                        { name: "Monotributista",         color: "yellow" },
                    ]
                }
            },
            "Condición Venta": {
                select: {
                    options: [
                        { name: "Contado",       color: "green"  },
                        { name: "Transferencia", color: "blue"   },
                        { name: "Cuenta Cte",    color: "orange" },
                    ]
                }
            },
            // Estado actualizado con las nuevas opciones del daemon
            "Estado": {
                select: {
                    options: [
                        { name: "🚀 Emitir",      color: "blue"   },
                        { name: "🗑️ Anular",      color: "orange" },
                        { name: "⏳ Procesando",  color: "yellow" },
                        { name: "✅ Aprobada",    color: "green"  },
                        { name: "❌ Rechazada",   color: "red"    },
                        { name: "🔄 Anulada",     color: "purple" },
                    ]
                }
            },
            // Campo para mensajes de error del daemon
            "Error": {
                rich_text: {}
            },
        }
    });

    console.log("✅ Schema actualizado correctamente.");
    console.log("\nColumnas agregadas:");
    console.log("  • Domicilio       (texto)");
    console.log("  • Condición IVA   (selección)");
    console.log("  • Condición Venta (selección)");
    console.log("  • Error           (texto — lo escribe el daemon automáticamente)");
    console.log("  • Estado          (actualizado con opciones 🚀 Emitir y 🗑️ Anular)");
}

main().catch(err => console.error("❌ Error:", err.message));
